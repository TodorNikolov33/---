from fastapi import APIRouter

router = APIRouter()

@router.get("/posts")
def get_posts():
    return ["Post1", "Post2"]