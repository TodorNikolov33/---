from fastapi import APIRouter

router = APIRouter()

@router.get("/comments")
def get_comments():
    return ["Comment1", "Comment2"]