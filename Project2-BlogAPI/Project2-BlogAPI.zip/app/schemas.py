from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class ShowUser(BaseModel):
    id: int
    username: str
    email: str
    class Config:
        orm_mode = True

class PostCreate(BaseModel):
    title: str
    content: str

class ShowPost(BaseModel):
    id: int
    title: str
    content: str
    created_at: datetime
    author_id: int
    class Config:
        orm_mode = True

class CommentCreate(BaseModel):
    content: str

class ShowComment(BaseModel):
    id: int
    content: str
    created_at: datetime
    post_id: int
    class Config:
        orm_mode = True