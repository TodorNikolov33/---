from fastapi import FastAPI
from app.database import engine, Base
from app.routes import users, posts, comments

Base.metadata.create_all(bind=engine)

app = FastAPI(title="BlogAPI")

app.include_router(users.router, prefix="/api")
app.include_router(posts.router, prefix="/api")
app.include_router(comments.router, prefix="/api")