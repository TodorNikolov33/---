using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace Project4_ChatAppSignalR.Controllers
{
    [Authorize]
    public class ChatController : Controller
    {
        public IActionResult Index() => View();
    }
}