using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Project4_ChatAppSignalR.Models;
using System.Threading.Tasks;

namespace Project4_ChatAppSignalR.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public IActionResult Login() => View();
        public IActionResult Register() => View();
    }
}