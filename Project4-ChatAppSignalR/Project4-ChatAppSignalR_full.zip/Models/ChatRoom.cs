namespace Project4_ChatAppSignalR.Models
{
    public class ChatRoom
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}