using Microsoft.AspNetCore.Identity;

namespace Project4_ChatAppSignalR.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Допълнителни свойства
    }
}